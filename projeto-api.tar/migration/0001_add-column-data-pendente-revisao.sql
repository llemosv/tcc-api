ALTER TABLE "task_topics" ADD COLUMN "data_pendente_revisao" date;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "data_pendente_revisao" date;
ALTER TABLE "task_topics" ADD COLUMN "justificativa" text;--> statement-breakpoint
ALTER TABLE "tasks" ADD COLUMN "justificativa" text;
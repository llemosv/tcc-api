export type TopicMessageDTO = {
  id_mensagem: string;
  id_topic: string;
  id_autor: string;
  conteudo: string;
  data_criacao: string;
  autor: string;
};

export interface StudentGuidancesDTO {
  id_orientacao: string;
  aluno: string;
  orientador: string;
  tema: string;
  previsao_entrega: string;
  solicitacao_aceita: boolean;
}

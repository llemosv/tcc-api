export interface TasksCount {
  status: string;
  deliveries: number;
  fill: string;
}

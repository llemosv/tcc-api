export interface TasksPendingApproval {
  id: string;
  id_tcc: string;
  tarefa: string;
  data_criacao: string;
  solicitacao_revisao: string;
  previsao_entrega: string;
}

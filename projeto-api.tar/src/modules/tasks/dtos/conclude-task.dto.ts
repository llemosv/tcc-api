export interface ConcludeTaskDTO {
  conclude: boolean;
  justification: string;
}
